// components/HeroSection.js
import React from 'react';

function HeroSection() {
    return (
        <section className="relative overflow-hidden bg-gradient-to-b from-blue-300 via-blue-200 to-green-200 text-black py-6 pb-0 md:px-24">
            {/* Plain White Blob Background Shape */}



            {/* Content */}
            <div className="relative z-10 mx-auto flex flex-col md:flex-row items-center p-8 pb-0">
                {/* Left Section */}
                <div className="flex-1 text-center md:text-left">
                    <h1 className="text-6xl text-black opacity-85 mb-4 font-primary font-medium leading-extra-loose">
                        Vista, <br /> a redefined ASPM
                    </h1>
                    <p className="text-xl md:text-2xl mb-6 text-black opacity-70 font-secondary">
                        An AI-powered, tool-agnostic digital security solution created by FortiMinds
                    </p>
                </div>

                {/* Placeholder for Right Image */}
                <div className="flex-1 mt-10 md:mt-0">
                    {/* <div className="w-full h-64 md:h-96 bg-white/10 rounded-lg flex items-center justify-center">
                        <span className="text-2xl text-gray-200">

                        </span>
                    </div> */}
                    <img src="./images/constellation-cropped@3x.svg" alt="" />


                </div>
            </div>
        </section>
    );
}

export default HeroSection;
